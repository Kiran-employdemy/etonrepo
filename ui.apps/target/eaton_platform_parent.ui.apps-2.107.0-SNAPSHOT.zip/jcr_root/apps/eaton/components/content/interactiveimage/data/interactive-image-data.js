"use strict";

var JSONObject = org.apache.sling.commons.json.JSONObject;

use(function() {

//data array to be used in javascript for this component interactive-image.js
    var imageJsData = new JSONObject();
   

 return {
   imageJsData :imageJsData.toString()
 };

});