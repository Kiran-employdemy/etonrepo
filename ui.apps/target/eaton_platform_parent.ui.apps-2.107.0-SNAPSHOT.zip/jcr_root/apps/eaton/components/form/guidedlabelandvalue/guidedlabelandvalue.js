use(function () {
    var options = this.options;
    return {
        options: options.split(',')
    };
});
